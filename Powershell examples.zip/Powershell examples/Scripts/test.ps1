if (condition) {
    <# Action to perform if the condition is true #>
}